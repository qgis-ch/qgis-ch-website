# Path to LTOP .koo file with approximate coordinates
# File path on Linux:
#koo_file = '/home/path/to/your/directory/schoenegg_nk.koo'
# File path on Windows:
koo_file = r'C:\\Users\path\to\your\directory\schoenegg.koo'
# Path to LTOP .mes file with the geodetic measurements
# File path on Linux:
#mes_file = '/home/path/to/your/directory/schoenegg_messungen.mes'
# File path on Windows:
mes_file = r'C:\\Users\path\to\your\directory\schoenegg.mes'
# Beware: this is _not_ best practice how to store file paths in Python. There are better,
# platform-independent ways to do that!

# Create a memory layer to store the approximate coordinates
# see https://docs.qgis.org/3.16/en/docs/pyqgis_developer_cookbook/vector.html#from-an-instance-of-qgsvectorlayer
koo_layer = QgsVectorLayer("Point?crs=epsg:2056&index=yes", "Naeherungskoordinaten", "memory")
# Get the data provider for this layer
koo_provider = koo_layer.dataProvider()

# Add fields for point name, easting and northing
# see also the example in the documentation:
# https://docs.qgis.org/3.16/en/docs/pyqgis_developer_cookbook/vector.html#from-an-instance-of-qgsvectorlayer
koo_provider.addAttributes([QgsField("Punktname", QVariant.String),
                    QgsField("Rechtswert",  QVariant.Double),
                    QgsField("Hochwert", QVariant.Double)])
# Tell the vector layer to fetch changes from the provider
koo_layer.updateFields() 

# Init an empty Python dict to store the approximate coordinates (from 
# stations and targets) in the follwing format:
# {
#  'Pt1': [2613903.991, 1175233.672],
#  'Pt2': [2613889.508, 1175157.881],
#  'Pt3': [2613787.706, 1175225.505],
#  .....
# }
# This dict is later used when writing the measurements
coordinates = {}

# Using readlines()
with open(koo_file, 'r') as file1:
    lines = file1.readlines()
    count = 0
    # Strips the newline character
    for line in lines:
        # Lines starting with $$ are comments
        if line.startswith('$$'):
            continue
        count += 1
        # Get the point name and strip spaces
        punktname = line.strip()[0:32].rstrip()
        # Get the easting
        rechtswert = float(line.strip()[32:44].rstrip())
        # Get the northing
        hochwert = float(line.strip()[44:56].rstrip())

        # Add coordinates to dict
        coordinates[punktname] = [rechtswert, hochwert]
        
        # Create a new feature
        fet = QgsFeature()
        # Create a new point geometry with easting and northing
        point = QgsGeometry.fromPointXY(QgsPointXY(rechtswert,hochwert))
        # Add this point to the current feature
        fet.setGeometry(point)
        # Set the attributes
        fet.setAttributes([punktname, rechtswert, hochwert])    
        # Add the feature to the provider
        koo_provider.addFeatures([fet])
        
        # Optional logging
        QgsMessageLog.logMessage("Punkt %s: %s,%s" % (punktname, rechtswert, hochwert), 'Load .mes File', level=Qgis.Info)

# update layer's extent when new features have been added
# because change of extent in provider is not propagated to the layer
koo_layer.updateExtents()

# Add the layer to the map
QgsProject.instance().addMapLayer(koo_layer)

# Read the geodetic measurements:
# Create an memory vector layer
mes_layer = QgsVectorLayer("Linestring?crs=epsg:2056&index=yes", "Messungen", "memory")
# Get the vector provider
mes_provider = mes_layer.dataProvider()

# Add fields "Station", "Ziel" and "Beobachtung"
mes_provider.addAttributes([QgsField("Station", QVariant.String),
                    QgsField("Ziel",  QVariant.String),
                    QgsField("Beobachtung", QVariant.String)])
# Tell the vector layer to fetch changes from the provider
mes_layer.updateFields()

# Start reading the .mes file.
# Open the file read-only
with open(mes_file, 'r') as file1:
    count = 0
    # Init a variable to store the current station
    station = ''
    # Using readlines()
    lines = file1.readlines()
    # Loop over all lines
    for line in lines:
        count += 1
        # Lines with $$ are comments, skip this line
        if line.startswith('$$'):
            continue
        # Lines starting with ST indicate new stations
        # Write the new station to the variable "station"
        elif line.startswith('ST'):
            # Remove blanks with .rstrip()
            station = line.strip()[2:11].rstrip()
            # and go to the next line
            continue
        # New observation "RI"
        elif line.startswith('RI'):
            # Get the target
            ziel = line.strip()[2:11].rstrip()
            # Store the type of observation
            beob = 'RI'
        elif line.startswith('DS'):
            # Get the target
            ziel = line.strip()[2:11].rstrip()
            # Store the type of observation
            beob = 'DS'
        else:
            # In all other cases go to the next line
            continue
        
        #print("{} - {}".format(station, ziel))
        
        # Create an array with two points: first point is the station,
        # second point is the target
        l = [QgsPoint(coordinates[station][0],coordinates[station][1]),
            QgsPoint(coordinates[ziel][0],coordinates[ziel][1])]
        
        # Create and add a feature
        fet = QgsFeature()
        # Create a linestring geometry from the array
        linestring = QgsGeometry.fromPolyline(l)
        # Optional loggin
        QgsMessageLog.logMessage("%s" % (linestring.asWkt(3)), 'Load .mes File', level=Qgis.Info)
        # Add the geometry to the current feature
        fet.setGeometry(linestring)
        # Set the attributes
        fet.setAttributes([station, ziel, beob])
        # Add the feature to the provider
        mes_provider.addFeatures([fet])

# update layer's extent when new features have been added
# because change of extent in provider is not propagated to the layer
mes_layer.updateExtents()

# Add the layer to the map
QgsProject.instance().addMapLayer(mes_layer)
