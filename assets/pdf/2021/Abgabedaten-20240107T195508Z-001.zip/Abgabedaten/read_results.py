# Path to LTOP .prn file
# File path on Linux:
#prn_file = '/home/path/to/your/directory/schoren.prn'
# File path on Windows:
prn_file = r'C:\Users\path\to\your\directory\schoenegg.prn'
# Beware: this is _not_ best practice how to store file paths in Python. There are better,
# platform-independent ways to do that!

# Create a new memory layer
prn_layer = QgsVectorLayer("Point?crs=epsg:2056&index=yes", "Resultate", "memory")
# Get the corresponding provider
prn_provider = prn_layer.dataProvider()

# Add fields to the memory layer
prn_provider.addAttributes([QgsField("Punktname", QVariant.String),
                    # Easting as Double
                    QgsField("Rechtswert",  QVariant.Double),
                    # Northing as Double
                    QgsField("Hochwert", QVariant.Double),
                    # Halbachse A der mittleren Fehlerellipse
                    QgsField("MFA", QVariant.Double),
                    # Halbachse B der mittleren Fehlerellipse
                    QgsField("MFB", QVariant.Double),
                    # Azimut der Halbachse A
                    QgsField("AZI_A", QVariant.Double)])
# Tell the vector layer to fetch changes from the provider
prn_layer.updateFields() 

# Open the file in read-only mode
with open(prn_file, 'r') as file1:
    # Get a list of all lines
    lines = file1.readlines()
    
    # Init a boolean variable to store if line needs to be read
    read_table = False
    # Strips the newline character
    for line in lines:
        # As soon as the following line is found:
        # KOORDINATEN UND HOEHEN, NEUPUNKTE MIT AENDERUNGEN UND MITTL. FEHLERELLIPSEN                LAND : CH
        # the lines are read and interpreted:
        if r'MITTL. FEHLERELLIPSEN' in line:
            # Set read_table to true
            read_table = True
            # and go to the next line
            continue
        # Skip the decoration line
        if line.lstrip().startswith('****') and read_table:
            continue
        # Skip the line
        # PUNKT    TYP         Y           X         H         DY      DX      DH     MFA   MFB   AZI_A   MFH  MESSELEM.
        if line.lstrip().startswith('PUNKT') and read_table:
            continue
        # Skip the line
        #                       M           M         M         MM      MM      MM     MM    MM      G     MM   LAGE HOE
        # as well
        if line.startswith('             ') and read_table:
            continue
        # Stop reading the lines as soon as the line
        #  BA FUER LANDESTOPOGRAPHIE    TITEL: 
        # is found by setting read_table to false
        if r'FUER LANDESTOPOGRAPHIE' in line and read_table:
            read_table = False
            continue
        # Else if read_table is true, parse the line
        elif read_table:
            # Get the point name
            punktname = line[2:13].rstrip()
            # Get the easting and cast it to a number
            rechtswert = float(line[16:27])
            # Get the northin and cast it to a number
            hochwert = float(line[28:40])
            mfa = None
            # Get the Halbachse A and cast it to a number
            if line[76:81].strip() != '':
                mfa = float(line[76:81])
            mfb = None
            # Get the Halbachse B and cast it to a number
            if line[82:87].strip() != '':
                mfb = float(line[82:87])
            azi_a = None
            # Get the azimuth of Halbachse A and cast it to a number
            if line[88:94].strip() != '':
                azi_a = float(line[88:94])
        
            # Create a new feature
            fet = QgsFeature()
            # Create a point geometry from easting and northing
            point = QgsGeometry.fromPointXY(QgsPointXY(rechtswert,hochwert))
            # Add the point to the new feature
            fet.setGeometry(point)
            # Set the attributes
            fet.setAttributes([punktname, rechtswert, hochwert, mfa, mfb, azi_a])
            # Add the new feature to the provider
            prn_provider.addFeatures([fet])

# update layer's extent when new features have been added
# because change of extent in provider is not propagated to the layer
prn_layer.updateExtents()

# Add the layer to the map
QgsProject.instance().addMapLayer(prn_layer)
